import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [prompt, setPrompt] = useState("");
  const [answer, setAnswer] = useState("");

  const handleSubmit = async () => {
    try {
      const res = await axios.post("http://localhost:3000/solve", { prompt });
      setAnswer(res.data.answer);
    } catch (err) {
      setAnswer("Error: Unable to connect to the server.");
    }
  };

  return (
    <div>
      <h1>CodeRabbit Clone</h1>
      <textarea
        placeholder="Paste code or write your question here..."
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
      />
      <br />
      <button onClick={handleSubmit}>Submit</button>
      <pre>{answer}</pre>
    </div>
  );
}

export default App;